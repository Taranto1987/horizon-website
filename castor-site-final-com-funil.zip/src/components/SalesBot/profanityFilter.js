const profanityList = [
  "arrombado", "babaca", "bosta", "cagar", "caralho", "cu", "foder", "foda-se", "merda", "pau", "pinto", "porra", "puta", "puta que pariu", "rola", "saco", "tesão", "vai se foder", "vai tomar no cu", "vtnc", "vsf", "fdp", "crlh", "prr"
];

export const containsProfanity = (text) => {
  const lowerCaseText = text.toLowerCase();
  return profanityList.some(word => lowerCaseText.includes(word));
};

export const filterProfanity = (text) => {
  let filteredText = text;
  profanityList.forEach(word => {
    const regex = new RegExp(`\\b${word}\\b`, "gi");
    filteredText = filteredText.replace(regex, "****"); // Substitui a palavra por asteriscos
  });
  return filteredText;
};

