import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { Star, ShoppingCart, Zap, Shield, Award, RefreshCw, Bed, Package, Tag, Users, TrendingUp } from 'lucide-react';

const ProductGrid = ({ onProductSelect }) => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('todos');
  const [happyCustomers, setHappyCustomers] = useState(0);

  useEffect(() => {
    let count = 0;
    const targetCustomers = 137 + Math.floor(Math.random() * 50); 
    const interval = setInterval(() => {
      count += Math.floor(Math.random() * 5) + 1;
      if (count >= targetCustomers) {
        setHappyCustomers(targetCustomers);
        clearInterval(interval);
      } else {
        setHappyCustomers(count);
      }
    }, 80);
    return () => clearInterval(interval);
  }, []);

  // Imagens de exemplo para os produtos Castor
  const imageUrls = {
    'Amazon Premium Gel One Face Pocket': 'https://lojacastor.com.br/media/catalog/product/cache/f3248366443af48277be0f103435b768/c/o/conjunto_amazon_premium_gel_pocket_amb_casal.jpg',
    'Fontana Euro One Face Pocket': 'https://lojacastor.com.br/media/catalog/product/cache/f3248366443af48277be0f103435b768/c/o/conjunto_fontana_euro_pocket_amb_casal.jpg',
    'Kingdom Aloe Vera Double Face Pocket': 'https://lojacastor.com.br/media/catalog/product/cache/f3248366443af48277be0f103435b768/c/o/conjunto_kingdom_aloe_vera_pocket_amb_casal.jpg',
    'Plush Light Stress One Face Pocket': 'https://lojacastor.com.br/media/catalog/product/cache/f3248366443af48277be0f103435b768/c/o/conjunto_plush_light_stress_pocket_amb_casal.jpg',
    'Innovation New Plus One Face Híbrido': 'https://lojacastor.com.br/media/catalog/product/cache/f3248366443af48277be0f103435b768/c/o/conjunto_innovation_new_plus_hibrido_amb_casal.jpg',
    'Silver Star Air One Face Híbrido': 'https://lojacastor.com.br/media/catalog/product/cache/f3248366443af48277be0f103435b768/c/o/conjunto_silver_star_air_hibrido_amb_casal.jpg',
    'New Class Tecnopedic One Face': 'https://lojacastor.com.br/media/catalog/product/cache/f3248366443af48277be0f103435b768/c/o/conjunto_new_class_tecnopedic_amb_casal.jpg',
    'Silver Star Air One Face Tecnopedic': 'https://lojacastor.com.br/media/catalog/product/cache/f3248366443af48277be0f103435b768/c/o/conjunto_silver_star_air_tecnopedic_amb_casal.jpg',
    'Premium One Face Tecnopedic': 'https://lojacastor.com.br/media/catalog/product/cache/f3248366443af48277be0f103435b768/c/o/conjunto_premium_one_face_tecnopedic_amb_casal.jpg',
    'Sleep Max Double Face D33 – 18 cm': 'https://lojacastor.com.br/media/catalog/product/cache/f3248366443af48277be0f103435b768/c/o/conjunto_sleep_max_d33_amb_casal.jpg',
    'Sleep Max Double Face D33 – 25 cm': 'https://lojacastor.com.br/media/catalog/product/cache/f3248366443af48277be0f103435b768/c/o/conjunto_sleep_max_d33_amb_casal.jpg',
    'Red White Double Face D33 – 27 cm': 'https://lojacastor.com.br/media/catalog/product/cache/f3248366443af48277be0f103435b768/c/o/conjunto_red_white_d33_amb_casal.jpg',
    'Sleep Max Double Face D45 – 18 cm': 'https://lojacastor.com.br/media/catalog/product/cache/f3248366443af48277be0f103435b768/c/o/conjunto_sleep_max_d45_amb_casal.jpg',
    'Sleep Max Double Face D45 – 25 cm': 'https://lojacastor.com.br/media/catalog/product/cache/f3248366443af48277be0f103435b768/c/o/conjunto_sleep_max_d45_amb_casal.jpg',
    'Red White Double Face D45 – 27 cm': 'https://lojacastor.com.br/media/catalog/product/cache/f3248366443af48277be0f103435b768/c/o/conjunto_red_white_d45_amb_casal.jpg',
    'Travesseiro Viscoelástico Castor': 'https://lojacastor.com.br/media/catalog/product/cache/f3248366443af48277be0f103435b768/t/r/travesseiro_viscoelastico_castor.jpg',
    'Protetor Impermeável Premium': 'https://lojacastor.com.br/media/catalog/product/cache/f3248366443af48277be0f103435b768/p/r/protetor_impermeavel_premium.jpg',
  };

  const castorProductsData = [
    // Colchões - Linha Pocket (Molas Ensacadas)
    {
      id: 'amazon-premium-gel-pocket',
      name: 'Amazon Premium Gel One Face Pocket',
      type: 'colchao',
      category: 'Pocket',
      price: 2899.90, // Preço fictício
      originalPrice: 3500.00,
      image_url: imageUrls['Amazon Premium Gel One Face Pocket'],
      image_placeholder: 'Colchão Amazon Premium Gel One Face Pocket',
      rating: 4.9,
      reviews: 120,
      features: ['Molas Ensacadas', 'Pillow Top One Face', 'Gel Sense', 'Conforto Firme'],
      sizes: ['Solteiro', 'Casal', 'Queen', 'King'],
      shortDesc: 'Tecnologia de molas ensacadas com gel para noites frescas e suporte individualizado.',
      fullDescription: 'O Colchão Amazon Premium Gel One Face Pocket oferece o que há de mais moderno em conforto e tecnologia. Suas molas ensacadas individualmente proporcionam um suporte perfeito para cada parte do corpo, enquanto a camada de gel dissipa o calor, garantindo um sono fresco e reparador. Ideal para quem busca firmeza e individualidade no movimento.',
    },
    {
      id: 'fontana-euro-pocket',
      name: 'Fontana Euro One Face Pocket',
      type: 'colchao',
      category: 'Pocket',
      price: 2599.90,
      originalPrice: 3200.00,
      image_url: imageUrls['Fontana Euro One Face Pocket'],
      image_placeholder: 'Colchão Fontana Euro One Face Pocket',
      rating: 4.8,
      reviews: 100,
      features: ['Molas Ensacadas', 'Pillow Top Euro', 'Tecido em Malha', 'Conforto Intermediário'],
      sizes: ['Casal', 'Queen', 'King'],
      shortDesc: 'Conforto intermediário com molas ensacadas e design elegante Euro Pillow.',
      fullDescription: 'O Fontana Euro One Face Pocket combina a estabilidade das molas ensacadas com o toque suave do Euro Pillow. Proporciona um conforto intermediário, adaptando-se bem a diferentes biotipos e posições de dormir. Seu tecido em malha garante um toque agradável e maior respirabilidade.',
    },
    {
      id: 'kingdom-aloe-vera-pocket',
      name: 'Kingdom Aloe Vera Double Face Pocket',
      type: 'colchao',
      category: 'Pocket',
      price: 3299.90,
      originalPrice: 4000.00,
      image_url: imageUrls['Kingdom Aloe Vera Double Face Pocket'],
      image_placeholder: 'Colchão Kingdom Aloe Vera Double Face Pocket',
      rating: 5.0,
      reviews: 150,
      features: ['Molas Ensacadas', 'Double Face', 'Tecido com Aloe Vera', 'Conforto Macio'],
      sizes: ['Casal', 'Queen', 'King'],
      shortDesc: 'Luxo e durabilidade com molas ensacadas e tratamento Aloe Vera para um sono revitalizante.',
      fullDescription: 'O Kingdom Aloe Vera Double Face Pocket é sinônimo de luxo e bem-estar. Com molas ensacadas e a tecnologia Double Face, oferece o dobro de vida útil. Seu tecido com tratamento de Aloe Vera proporciona uma sensação de frescor e cuidado com a pele, ideal para um sono macio e revitalizante.',
    },
    {
      id: 'plush-light-stress-pocket',
      name: 'Plush Light Stress One Face Pocket',
      type: 'colchao',
      category: 'Pocket',
      price: 2799.90,
      originalPrice: 3400.00,
      image_url: imageUrls['Plush Light Stress One Face Pocket'],
      image_placeholder: 'Colchão Plush Light Stress One Face Pocket',
      rating: 4.7,
      reviews: 90,
      features: ['Molas Ensacadas', 'Pillow Top One Face', 'Tecido Antiestresse', 'Conforto Firme'],
      sizes: ['Casal', 'Queen', 'King'],
      shortDesc: 'Firmeza e tecnologia antiestresse para um sono profundo e reparador.',
      fullDescription: 'O Plush Light Stress One Face Pocket foi desenvolvido para proporcionar um sono livre de tensões. Suas molas ensacadas garantem suporte individualizado, e o tecido com tecnologia antiestresse ajuda a neutralizar cargas eletrostáticas, promovendo um relaxamento completo. Ideal para quem busca firmeza e bem-estar.',
    },

    // Colchões - Linha Pocket Híbrido
    {
      id: 'innovation-new-plus-hibrido',
      name: 'Innovation New Plus One Face Híbrido',
      type: 'colchao',
      category: 'Pocket Híbrido',
      price: 3199.90,
      originalPrice: 3900.00,
      image_url: imageUrls['Innovation New Plus One Face Híbrido'],
      image_placeholder: 'Colchão Innovation New Plus One Face Híbrido',
      rating: 4.9,
      reviews: 110,
      features: ['Molas Ensacadas', 'Espuma Viscoelástica', 'Pillow Top One Face', 'Conforto Intermediário'],
      sizes: ['Casal', 'Queen', 'King'],
      shortDesc: 'A combinação perfeita de molas e espuma viscoelástica para suporte e conforto adaptável.',
      fullDescription: 'O Innovation New Plus One Face Híbrido une o melhor de dois mundos: a individualidade das molas ensacadas e o aconchego da espuma viscoelástica. O resultado é um colchão que se adapta perfeitamente aos contornos do corpo, aliviando pontos de pressão e garantindo um conforto intermediário ideal para a maioria dos biotipos.',
    },
    {
      id: 'silver-star-air-hibrido',
      name: 'Silver Star Air One Face Híbrido',
      type: 'colchao',
      category: 'Pocket Híbrido',
      price: 2999.90,
      originalPrice: 3600.00,
      image_url: imageUrls['Silver Star Air One Face Híbrido'],
      image_placeholder: 'Colchão Silver Star Air One Face Híbrido',
      rating: 4.8,
      reviews: 95,
      features: ['Molas Ensacadas', 'Espuma HR', 'Pillow Top One Face', 'Tecido Respirável'],
      sizes: ['Casal', 'Queen', 'King'],
      shortDesc: 'Híbrido com alta resiliência e excelente ventilação para um sono fresco e com suporte.',
      fullDescription: 'O Silver Star Air One Face Híbrido oferece um suporte firme e confortável graças à combinação de molas ensacadas e espuma de alta resiliência (HR). Seu tecido respirável e a estrutura que permite a circulação do ar garantem um ambiente de sono mais fresco e higiênico. Ideal para quem busca durabilidade e conforto.',
    },

    // Colchões - Linha Tecnopedic (Molas LFK)
    {
      id: 'new-class-tecnopedic',
      name: 'New Class Tecnopedic One Face',
      type: 'colchao',
      category: 'Tecnopedic',
      price: 1899.90,
      originalPrice: 2300.00,
      image_url: imageUrls['New Class Tecnopedic One Face'],
      image_placeholder: 'Colchão New Class Tecnopedic One Face',
      rating: 4.7,
      reviews: 80,
      features: ['Molas LFK', 'Pillow Top One Face', 'Suporte Firme', 'Tecido Resistente'],
      sizes: ['Casal', 'Queen', 'King'],
      shortDesc: 'Firmeza e durabilidade com molas LFK, ideal para quem busca suporte ortopédico.',
      fullDescription: 'O New Class Tecnopedic One Face é construído com molas LFK, que oferecem um suporte firme e contínuo, ideal para a saúde da coluna. Seu Pillow Top One Face proporciona um toque de conforto sem comprometer a firmeza. É a escolha perfeita para quem busca um colchão ortopédico e durável.',
    },
    {
      id: 'silver-star-air-tecnopedic',
      name: 'Silver Star Air One Face Tecnopedic',
      type: 'colchao',
      category: 'Tecnopedic',
      price: 2199.90,
      originalPrice: 2700.00,
      image_url: imageUrls['Silver Star Air One Face Tecnopedic'],
      image_placeholder: 'Colchão Silver Star Air One Face Tecnopedic',
      rating: 4.8,
      reviews: 75,
      features: ['Molas LFK', 'Pillow Top One Face', 'Tecido Respirável', 'Conforto Firme'],
      sizes: ['Casal', 'Queen', 'King'],
      shortDesc: 'Tecnopedic com tecnologia Air para maior ventilação e conforto térmico.',
      fullDescription: 'O Silver Star Air One Face Tecnopedic combina a robustez das molas LFK com a respirabilidade do tecido Air. Proporciona um suporte firme e um ambiente de sono mais fresco, ideal para quem busca alívio de dores e conforto térmico. Sua durabilidade é um diferencial.',
    },
    {
      id: 'premium-one-face-tecnopedic',
      name: 'Premium One Face Tecnopedic',
      type: 'colchao',
      category: 'Tecnopedic',
      price: 2399.90,
      originalPrice: 2900.00,
      image_url: imageUrls['Premium One Face Tecnopedic'],
      image_placeholder: 'Colchão Premium One Face Tecnopedic',
      rating: 4.9,
      reviews: 85,
      features: ['Molas LFK', 'Pillow Top One Face', 'Conforto Extra Firme', 'Tecido de Alta Qualidade'],
      sizes: ['Casal', 'Queen', 'King'],
      shortDesc: 'O máximo em firmeza e suporte ortopédico com acabamento premium.',
      fullDescription: 'O Premium One Face Tecnopedic é a escolha ideal para quem necessita de um suporte extra firme. Suas molas LFK de alta resistência e o Pillow Top One Face garantem o alinhamento perfeito da coluna, enquanto o tecido de alta qualidade proporciona um toque sofisticado. É um investimento em saúde e durabilidade.',
    },

    // Colchões - Linha Espuma D33/D45
    {
      id: 'sleep-max-d33-18',
      name: 'Sleep Max Double Face D33 – 18 cm',
      type: 'colchao',
      category: 'Espuma D33',
      price: 999.90,
      originalPrice: 1200.00,
      image_url: imageUrls['Sleep Max Double Face D33 – 18 cm'],
      image_placeholder: 'Colchão Sleep Max Double Face D33 – 18 cm',
      rating: 4.5,
      reviews: 60,
      features: ['Espuma D33', 'Double Face', '18 cm de altura', 'Conforto Firme'],
      sizes: ['Solteiro', 'Casal', 'Queen', 'King'],
      shortDesc: 'Colchão de espuma D33 com dupla face para maior durabilidade e conforto firme.',
      fullDescription: 'O Sleep Max Double Face D33 – 18 cm é um colchão versátil e durável. Sua espuma D33 oferece um suporte firme e a tecnologia Double Face permite o uso dos dois lados, prolongando a vida útil do produto. Ideal para quem busca um colchão de espuma de qualidade com bom custo-benefício.',
    },
    {
      id: 'sleep-max-d33-25',
      name: 'Sleep Max Double Face D33 – 25 cm',
      type: 'colchao',
      category: 'Espuma D33',
      price: 1199.90,
      originalPrice: 1450.00,
      image_url: imageUrls['Sleep Max Double Face D33 – 25 cm'],
      image_placeholder: 'Colchão Sleep Max Double Face D33 – 25 cm',
      rating: 4.6,
      reviews: 70,
      features: ['Espuma D33', 'Double Face', '25 cm de altura', 'Conforto Firme'],
      sizes: ['Solteiro', 'Casal', 'Queen', 'King'],
      shortDesc: 'Versão mais alta do Sleep Max D33, oferecendo maior conforto e durabilidade.',
      fullDescription: 'Com 25 cm de altura, o Sleep Max Double Face D33 proporciona um conforto firme e uma sensação de maior volume. A espuma D33 e a tecnologia Double Face garantem durabilidade e um suporte adequado para a coluna. É uma excelente opção para quem busca um colchão de espuma de alta qualidade.',
    },
    {
      id: 'red-white-d33-27',
      name: 'Red White Double Face D33 – 27 cm',
      type: 'colchao',
      category: 'Espuma D33',
      price: 1399.90,
      originalPrice: 1700.00,
      image_url: imageUrls['Red White Double Face D33 – 27 cm'],
      image_placeholder: 'Colchão Red White Double Face D33 – 27 cm',
      rating: 4.7,
      reviews: 80,
      features: ['Espuma D33', 'Double Face', '27 cm de altura', 'Design Moderno'],
      sizes: ['Solteiro', 'Casal', 'Queen', 'King'],
      shortDesc: 'Design moderno e conforto firme com 27 cm de altura para uma experiência premium.',
      fullDescription: 'O Red White Double Face D33 – 27 cm é um colchão que une design e funcionalidade. Sua espuma D33 oferece um suporte firme e a altura de 27 cm proporciona uma presença imponente no quarto. A tecnologia Double Face garante maior vida útil, e o design Red White adiciona um toque de modernidade.',
    },
    {
      id: 'sleep-max-d45-18',
      name: 'Sleep Max Double Face D45 – 18 cm',
      type: 'colchao',
      category: 'Espuma D45',
      price: 1299.90,
      originalPrice: 1550.00,
      image_url: imageUrls['Sleep Max Double Face D45 – 18 cm'],
      image_placeholder: 'Colchão Sleep Max Double Face D45 – 18 cm',
      rating: 4.6,
      reviews: 65,
      features: ['Espuma D45', 'Double Face', '18 cm de altura', 'Suporte Extra Firme'],
      sizes: ['Solteiro', 'Casal', 'Queen', 'King'],
      shortDesc: 'Colchão de espuma D45 para suporte extra firme e durabilidade superior.',
      fullDescription: 'O Sleep Max Double Face D45 – 18 cm é ideal para quem busca um suporte extra firme. Sua espuma D45 de alta densidade oferece o apoio necessário para a coluna, sendo recomendado para biotipos mais pesados ou para quem prefere uma superfície bem firme. A tecnologia Double Face aumenta a durabilidade.',
    },
    {
      id: 'sleep-max-d45-25',
      name: 'Sleep Max Double Face D45 – 25 cm',
      type: 'colchao',
      category: 'Espuma D45',
      price: 1499.90,
      originalPrice: 1800.00,
      image_url: imageUrls['Sleep Max Double Face D45 – 25 cm'],
      image_placeholder: 'Colchão Sleep Max Double Face D45 – 25 cm',
      rating: 4.7,
      reviews: 75,
      features: ['Espuma D45', 'Double Face', '25 cm de altura', 'Suporte Extra Firme'],
      sizes: ['Solteiro', 'Casal', 'Queen', 'King'],
      shortDesc: 'Versão mais alta do Sleep Max D45, com maior conforto e suporte para biotipos exigentes.',
      fullDescription: 'Com 25 cm de altura, o Sleep Max Double Face D45 oferece um suporte extra firme e uma sensação de maior volume. A espuma D45 de alta densidade garante o alinhamento da coluna e a tecnologia Double Face proporciona maior vida útil. É a escolha perfeita para quem busca firmeza e durabilidade.',
    },
    {
      id: 'red-white-d45-27',
      name: 'Red White Double Face D45 – 27 cm',
      type: 'colchao',
      category: 'Espuma D45',
      price: 1699.90,
      originalPrice: 2000.00,
      image_url: imageUrls['Red White Double Face D45 – 27 cm'],
      image_placeholder: 'Colchão Red White Double Face D45 – 27 cm',
      rating: 4.8,
      reviews: 85,
      features: ['Espuma D45', 'Double Face', '27 cm de altura', 'Design Moderno'],
      sizes: ['Solteiro', 'Casal', 'Queen', 'King'],
      shortDesc: 'Design sofisticado e suporte extra firme com 27 cm de altura.',
      fullDescription: 'O Red White Double Face D45 – 27 cm é um colchão que se destaca pelo design moderno e pelo suporte extra firme. Sua espuma D45 de alta densidade e a altura de 27 cm garantem uma experiência de sono superior. A tecnologia Double Face e o design Red White o tornam uma peça única no seu quarto.',
    },

    // Conjuntos (Cama + Colchão) - Representados como produtos separados para exibição
    {
      id: 'conjunto-amazon-premium-gel',
      name: 'Conjunto Amazon Premium Gel + Cama Box',
      type: 'conjunto',
      category: 'Pocket',
      price: 3899.90,
      originalPrice: 4500.00,
      image_url: imageUrls['Amazon Premium Gel One Face Pocket'], // Usando a imagem do colchão base
      image_placeholder: 'Conjunto Amazon Premium Gel + Cama Box',
      rating: 4.9,
      reviews: 115,
      features: ['Colchão Amazon Premium Gel', 'Cama Box', 'Molas Ensacadas', 'Gel Sense'],
      sizes: ['Solteiro', 'Casal', 'Queen', 'King'],
      shortDesc: 'Conjunto completo com colchão de molas ensacadas e gel, e cama box.',
      fullDescription: 'O Conjunto Amazon Premium Gel + Cama Box oferece a solução completa para o seu quarto. Inclui o colchão Amazon Premium Gel One Face Pocket, com molas ensacadas e tecnologia de gel para um sono fresco e individualizado, e uma cama box resistente e elegante. Conforto e praticidade em um só produto.',
    },
    {
      id: 'conjunto-fontana-euro',
      name: 'Conjunto Fontana Euro + Cama Box',
      type: 'conjunto',
      category: 'Pocket',
      price: 3599.90,
      originalPrice: 4200.00,
      image_url: imageUrls['Fontana Euro One Face Pocket'],
      image_placeholder: 'Conjunto Fontana Euro + Cama Box',
      rating: 4.8,
      reviews: 95,
      features: ['Colchão Fontana Euro', 'Cama Box', 'Molas Ensacadas', 'Euro Pillow'],
      sizes: ['Casal', 'Queen', 'King'],
      shortDesc: 'Conjunto com colchão de molas ensacadas e Euro Pillow, acompanhado de cama box.',
      fullDescription: 'O Conjunto Fontana Euro + Cama Box proporciona um conforto intermediário e um design sofisticado. Inclui o colchão Fontana Euro One Face Pocket, com molas ensacadas e Euro Pillow, e uma cama box que complementa perfeitamente o conjunto. Ideal para quem busca beleza e funcionalidade.',
    },
    {
      id: 'conjunto-kingdom-aloe-vera',
      name: 'Conjunto Kingdom Aloe Vera + Cama Box',
      type: 'conjunto',
      category: 'Pocket',
      price: 4299.90,
      originalPrice: 5000.00,
      image_url: imageUrls['Kingdom Aloe Vera Double Face Pocket'],
      image_placeholder: 'Conjunto Kingdom Aloe Vera + Cama Box',
      rating: 5.0,
      reviews: 145,
      features: ['Colchão Kingdom Aloe Vera', 'Cama Box', 'Molas Ensacadas', 'Aloe Vera'],
      sizes: ['Casal', 'Queen', 'King'],
      shortDesc: 'Conjunto luxuoso com colchão Double Face e tratamento Aloe Vera, e cama box.',
      fullDescription: 'O Conjunto Kingdom Aloe Vera + Cama Box é a expressão máxima de luxo e bem-estar. Com o colchão Kingdom Aloe Vera Double Face Pocket, que possui molas ensacadas e tratamento de Aloe Vera, e uma cama box elegante, este conjunto oferece um sono macio e revitalizante, além de durabilidade superior.',
    },
    {
      id: 'conjunto-plush-light-stress',
      name: 'Conjunto Plush Light Stress + Cama Box',
      type: 'conjunto',
      category: 'Pocket',
      price: 3799.90,
      originalPrice: 4400.00,
      image_url: imageUrls['Plush Light Stress One Face Pocket'],
      image_placeholder: 'Conjunto Plush Light Stress + Cama Box',
      rating: 4.7,
      reviews: 85,
      features: ['Colchão Plush Light Stress', 'Cama Box', 'Molas Ensacadas', 'Antiestresse'],
      sizes: ['Casal', 'Queen', 'King'],
      shortDesc: 'Conjunto com colchão de molas ensacadas e tecnologia antiestresse, e cama box.',
      fullDescription: 'O Conjunto Plush Light Stress + Cama Box foi criado para proporcionar um sono livre de tensões. Inclui o colchão Plush Light Stress One Face Pocket, com molas ensacadas e tecido antiestresse, e uma cama box que completa o ambiente de relaxamento. Ideal para quem busca firmeza e bem-estar completo.',
    },
    {
      id: 'conjunto-innovation-new-plus-hibrido',
      name: 'Conjunto Innovation New Plus Híbrido + Cama Box',
      type: 'conjunto',
      category: 'Pocket Híbrido',
      price: 4199.90,
      originalPrice: 4900.00,
      image_url: imageUrls['Innovation New Plus One Face Híbrido'],
      image_placeholder: 'Conjunto Innovation New Plus Híbrido + Cama Box',
      rating: 4.9,
      reviews: 105,
      features: ['Colchão Innovation New Plus Híbrido', 'Cama Box', 'Molas Ensacadas', 'Viscoelástica'],
      sizes: ['Casal', 'Queen', 'King'],
      shortDesc: 'Conjunto híbrido com molas e viscoelástico, e cama box, para conforto adaptável.',
      fullDescription: 'O Conjunto Innovation New Plus Híbrido + Cama Box oferece a combinação perfeita de molas ensacadas e espuma viscoelástica para um suporte e conforto adaptável. Acompanhado de uma cama box, este conjunto é ideal para quem busca tecnologia e bem-estar em um só produto.',
    },
    {
      id: 'conjunto-silver-star-air-hibrido',
      name: 'Conjunto Silver Star Air Híbrido + Cama Box',
      type: 'conjunto',
      category: 'Pocket Híbrido',
      price: 3999.90,
      originalPrice: 4600.00,
      image_url: imageUrls['Silver Star Air One Face Híbrido'],
      image_placeholder: 'Conjunto Silver Star Air Híbrido + Cama Box',
      rating: 4.8,
      reviews: 90,
      features: ['Colchão Silver Star Air Híbrido', 'Cama Box', 'Molas Ensacadas', 'Espuma HR'],
      sizes: ['Casal', 'Queen', 'King'],
      shortDesc: 'Conjunto híbrido com alta resiliência e ventilação, e cama box, para um sono fresco.',
      fullDescription: 'O Conjunto Silver Star Air Híbrido + Cama Box proporciona um suporte firme e um ambiente de sono fresco. Inclui o colchão Silver Star Air One Face Híbrido, com molas ensacadas e espuma HR, e uma cama box que complementa a estética e funcionalidade do conjunto. Durabilidade e conforto garantidos.',
    },
    {
      id: 'conjunto-new-class-tecnopedic',
      name: 'Conjunto New Class Tecnopedic + Cama Box',
      type: 'conjunto',
      category: 'Tecnopedic',
      price: 2899.90,
      originalPrice: 3400.00,
      image_url: imageUrls['New Class Tecnopedic One Face'],
      image_placeholder: 'Conjunto New Class Tecnopedic + Cama Box',
      rating: 4.7,
      reviews: 75,
      features: ['Colchão New Class Tecnopedic', 'Cama Box', 'Molas LFK', 'Suporte Firme'],
      sizes: ['Casal', 'Queen', 'King'],
      shortDesc: 'Conjunto com colchão de molas LFK e cama box, ideal para suporte ortopédico.',
      fullDescription: 'O Conjunto New Class Tecnopedic + Cama Box oferece um suporte firme e contínuo para a saúde da coluna. Inclui o colchão New Class Tecnopedic One Face, com molas LFK, e uma cama box resistente. É a escolha perfeita para quem busca um conjunto ortopédico e durável.',
    },
    {
      id: 'conjunto-silver-star-air-tecnopedic',
      name: 'Conjunto Silver Star Air Tecnopedic + Cama Box',
      type: 'conjunto',
      category: 'Tecnopedic',
      price: 3199.90,
      originalPrice: 3800.00,
      image_url: imageUrls['Silver Star Air One Face Tecnopedic'],
      image_placeholder: 'Conjunto Silver Star Air Tecnopedic + Cama Box',
      rating: 4.8,
      reviews: 70,
      features: ['Colchão Silver Star Air Tecnopedic', 'Cama Box', 'Molas LFK', 'Tecido Respirável'],
      sizes: ['Casal', 'Queen', 'King'],
      shortDesc: 'Conjunto Tecnopedic com tecnologia Air para maior ventilação e conforto térmico, e cama box.',
      fullDescription: 'O Conjunto Silver Star Air Tecnopedic + Cama Box combina a robustez das molas LFK com a respirabilidade do tecido Air. Proporciona um suporte firme e um ambiente de sono mais fresco, ideal para quem busca alívio de dores e conforto térmico. Acompanhado de uma cama box, oferece durabilidade e conforto.',
    },
    {
      id: 'conjunto-premium-one-face-tecnopedic',
      name: 'Conjunto Premium One Face Tecnopedic + Cama Box',
      type: 'conjunto',
      category: 'Tecnopedic',
      price: 3399.90,
      originalPrice: 4000.00,
      image_url: imageUrls['Premium One Face Tecnopedic'],
      image_placeholder: 'Conjunto Premium One Face Tecnopedic + Cama Box',
      rating: 4.9,
      reviews: 80,
      features: ['Colchão Premium One Face Tecnopedic', 'Cama Box', 'Molas LFK', 'Conforto Extra Firme'],
      sizes: ['Casal', 'Queen', 'King'],
      shortDesc: 'Conjunto com o máximo em firmeza e suporte ortopédico, e cama box, com acabamento premium.',
      fullDescription: 'O Conjunto Premium One Face Tecnopedic + Cama Box é a escolha ideal para quem necessita de um suporte extra firme. Inclui o colchão Premium One Face Tecnopedic, com molas LFK de alta resistência, e uma cama box que complementa o conjunto. É um investimento em saúde, durabilidade e sofisticação.',
    },
    {
      id: 'conjunto-sleep-max-d33-d45',
      name: 'Conjunto Sleep Max D33/D45 + Cama Box',
      type: 'conjunto',
      category: 'Espuma D33/D45',
      price: 1999.90,
      originalPrice: 2400.00,
      image_url: imageUrls['Sleep Max Double Face D33 – 25 cm'], // Usando imagem genérica
      image_placeholder: 'Conjunto Sleep Max D33/D45 + Cama Box',
      rating: 4.6,
      reviews: 60,
      features: ['Colchão Sleep Max D33/D45', 'Cama Box', 'Espuma de Alta Densidade', 'Double Face'],
      sizes: ['Solteiro', 'Casal', 'Queen', 'King'],
      shortDesc: 'Conjunto com colchão de espuma D33 ou D45 e cama box, para conforto firme e durabilidade.',
      fullDescription: 'O Conjunto Sleep Max D33/D45 + Cama Box oferece um suporte firme e durável. Inclui o colchão Sleep Max Double Face (D33 ou D45, dependendo da escolha) e uma cama box resistente. É uma opção versátil e econômica para quem busca um conjunto completo de qualidade.',
    },
    {
      id: 'conjunto-red-white-d33-d45',
      name: 'Conjunto Red White D33/D45 + Cama Box',
      type: 'conjunto',
      category: 'Espuma D33/D45',
      price: 2399.90,
      originalPrice: 2900.00,
      image_url: imageUrls['Red White Double Face D33 – 27 cm'], // Usando imagem genérica
      image_placeholder: 'Conjunto Red White D33/D45 + Cama Box',
      rating: 4.7,
      reviews: 70,
      features: ['Colchão Red White D33/D45', 'Cama Box', 'Espuma de Alta Densidade', 'Design Moderno'],
      sizes: ['Solteiro', 'Casal', 'Queen', 'King'],
      shortDesc: 'Conjunto com colchão de espuma D33 ou D45 e cama box, com design moderno e conforto firme.',
      fullDescription: 'O Conjunto Red White D33/D45 + Cama Box une design e funcionalidade. Inclui o colchão Red White Double Face (D33 ou D45, dependendo da escolha) e uma cama box que complementa o visual moderno. Oferece um suporte firme e durável, ideal para quem busca estilo e qualidade.',
    },

    // Acessórios
    {
      id: 'travesseiro-viscoelastico',
      name: 'Travesseiro Viscoelástico Castor',
      type: 'acessorio',
      category: 'Acessórios',
      price: 189.90,
      originalPrice: 250.00,
      image_url: imageUrls['Travesseiro Viscoelástico Castor'],
      image_placeholder: 'Travesseiro Viscoelástico Castor',
      rating: 4.9,
      reviews: 200,
      features: ['Espuma Viscoelástica', 'Moldável ao Contorno', 'Antialérgico', 'Capa Removível'],
      sizes: ['Padrão'],
      shortDesc: 'Conforto e suporte ideais para a cabeça e pescoço, moldando-se perfeitamente.',
      fullDescription: 'O Travesseiro Viscoelástico Castor é feito com espuma de alta tecnologia que se adapta aos contornos da cabeça e pescoço, proporcionando alinhamento ideal da coluna cervical. É antialérgico e possui capa removível para facilitar a higienização. Garanta um sono mais relaxante e sem dores.',
    },
    {
      id: 'protetor-impermeavel-premium',
      name: 'Protetor Impermeável Premium',
      type: 'acessorio',
      category: 'Acessórios',
      price: 129.90,
      originalPrice: 180.00,
      image_url: imageUrls['Protetor Impermeável Premium'],
      image_placeholder: 'Protetor Impermeável Premium',
      rating: 4.8,
      reviews: 180,
      features: ['100% Impermeável', 'Tecido Respirável', 'Proteção Antialérgica', 'Fácil de Lavar'],
      sizes: ['Solteiro', 'Casal', 'Queen', 'King'],
      shortDesc: 'Proteja seu colchão contra líquidos e alérgenos, prolongando sua vida útil.',
      fullDescription: 'O Protetor Impermeável Premium é essencial para manter seu colchão sempre novo e higienizado. Sua camada impermeável protege contra líquidos e manchas, enquanto o tecido respirável garante conforto. É antialérgico e fácil de lavar, proporcionando uma barreira eficaz contra ácaros e bactérias.',
    },
  ];

  useEffect(() => {
    const loadProducts = async () => {
      setLoading(true);
      await new Promise(resolve => setTimeout(resolve, 800)); 
      setProducts(castorProductsData);
      setLoading(false);
    };
    loadProducts();
  }, []);

  const handleAction = (product, actionType) => {
    const message = actionType === 'cart' 
      ? `${product.name} foi adicionado ao carrinho! Aproveite nossa oferta especial!`
      : `Iniciando compra de ${product.name}... Prepare-se para noites incríveis!`;
    toast({
      title: actionType === 'cart' ? "🛒 Produto no Carrinho!" : "🚀 Quase lá!",
      description: actionType === 'cart' ? message : "🚧 Esta funcionalidade (compra direta) ainda não está implementada. Você pode solicitar no próximo prompt! 🚀",
      duration: 4000,
      className: actionType === 'cart' ? 'toast-success-castor' : 'toast-info-castor'
    });
  };

  const refreshPrices = () => {
    toast({
      title: "🔄 Sincronizando Preços...",
      description: "Buscando as melhores ofertas na API oficial Loja Castor para você!",
      duration: 1500,
      className: 'toast-info-castor'
    });
    setTimeout(() => {
      toast({
        title: "✅ Preços Atualizados e Otimizados!",
        description: "Todos os preços estão em tempo real. Aproveite as ofertas exclusivas!",
        duration: 3000,
        className: 'toast-success-castor'
      });
    }, 1500);
  };

  const filteredProducts = products.filter(product => {
    if (filter === 'todos') return true;
    // Ajuste para filtrar por categoria de produto
    if (filter === 'colchoes') return product.type === 'colchao';
    if (filter === 'conjuntos-box') return product.type === 'conjunto';
    if (filter === 'acessorios') return product.type === 'acessorio';
    
    // Para filtros de categoria específicos (Pocket, Tecnopedic, etc.)
    return product.category.toLowerCase().replace(/\s+/g, '') === filter;
  });

  const filterButtons = [
    { label: 'Todos Modelos', value: 'todos', icon: Package },
    { label: 'Colchões', value: 'colchoes', icon: Bed },
    { label: 'Conj. box', value: 'conjuntos-box', icon: Bed },
    { label: 'Acessórios', value: 'acessorios', icon: Package },
    // Adicionar mais filtros de categoria se necessário, com base nos produtos reais
    { label: 'Pocket', value: 'pocket', icon: Bed },
    { label: 'Pocket Híbrido', value: 'pockethibrido', icon: Bed },
    { label: 'Tecnopedic', value: 'tecnopedic', icon: Bed },
    { label: 'Espuma D33', value: 'espumad33', icon: Bed },
    { label: 'Espuma D45', value: 'espumad45', icon: Bed },
  ];

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold gradient-text mb-4">
            Modelos de Colchões Castor
          </h1>
          <div className="flex items-center justify-center gap-2 text-muted-foreground">
            <RefreshCw className="w-5 h-5 animate-spin text-primary" />
            <span>Carregando os melhores colchões Castor para seu sono perfeito...</span>
          </div>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-8">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="glass-effect-castor rounded-2xl p-6 animate-pulse">
              <div className="w-full h-56 bg-secondary rounded-xl mb-4" />
              <div className="h-7 bg-secondary rounded mb-2" />
              <div className="h-5 bg-secondary rounded w-3/4 mb-4" />
              <div className="h-9 bg-secondary rounded" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <section id="produtos" className="py-16 md:py-20 bg-background/70">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl md:text-5xl font-bold gradient-text mb-4">
            Modelos de Colchões Castor
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto">
            Descubra a linha completa de colchões Castor, projetados para o seu conforto e bem-estar.
          </p>
        </motion.div>

        <div className="flex flex-wrap justify-center gap-3 mb-10">
          {filterButtons.map((btn) => (
            <Button
              key={btn.value}
              variant={filter === btn.value ? 'default' : 'outline'}
              onClick={() => setFilter(btn.value)}
              className="button-castor-outline"
            >
              {btn.icon && <btn.icon className="w-4 h-4 mr-2" />}
              {btn.label}
            </Button>
          ))}
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-8">
          {filteredProducts.map((product) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.5 }}
              className="glass-effect-castor rounded-2xl p-6 flex flex-col items-center text-center shadow-lg hover:shadow-xl transition-shadow duration-300"
            >
              <img
                src={product.image_url || 'https://via.placeholder.com/300'}
                alt={product.image_placeholder || product.name}
                className="w-full h-48 object-contain mb-4 rounded-lg"
              />
              <h2 className="text-xl font-semibold mb-2 text-foreground">{product.name}</h2>
              <p className="text-sm text-muted-foreground mb-3">{product.shortDesc}</p>
              
              <div className="flex items-center gap-1 mb-3">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-4 h-4 ${i < Math.floor(product.rating) ? 'text-yellow-400' : 'text-gray-300'}`}
                    fill={i < Math.floor(product.rating) ? 'currentColor' : 'none'}
                  />
                ))}
                <span className="text-xs text-muted-foreground">({product.reviews} avaliações)</span>
              </div>

              <div className="flex items-baseline gap-2 mb-4">
                {product.originalPrice && (
                  <span className="text-muted-foreground line-through text-sm">R$ {product.originalPrice.toFixed(2).replace('.', ',')}</span>
                )}
                <span className="text-2xl font-bold gradient-text">R$ {product.price.toFixed(2).replace('.', ',')}</span>
              </div>

              <div className="flex flex-wrap justify-center gap-2 mb-4">
                {product.features && product.features.map((feature, index) => (
                  <span key={index} className="bg-secondary text-secondary-foreground text-xs px-2 py-1 rounded-full">
                    {feature}
                  </span>
                ))}
              </div>

              <div className="mt-auto flex flex-col sm:flex-row gap-3 w-full">
                <Button
                  variant="default"
                  className="flex-1 button-castor-primary"
                  onClick={() => onProductSelect(product)}
                >
                  Ver Detalhes
                </Button>
                <Button
                  variant="outline"
                  className="flex-1 button-castor-outline"
                  onClick={() => handleAction(product, 'cart')}
                >
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  Adicionar ao Carrinho
                </Button>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="text-center mt-16"
        >
          <h2 className="text-3xl font-bold gradient-text mb-4">Junte-se aos nossos {happyCustomers}+ clientes satisfeitos!</h2>
          <p className="text-muted-foreground text-lg mb-6">
            Sua jornada para o sono perfeito começa aqui. Descubra o colchão Castor ideal para você.
          </p>
          <Button
            variant="default"
            size="lg"
            className="button-castor-primary"
            onClick={refreshPrices}
          >
            <Zap className="w-5 h-5 mr-2" />
            Ver Ofertas Exclusivas Agora!
          </Button>
        </motion.div>
      </div>
    </section>
  );
};

export default ProductGrid;


