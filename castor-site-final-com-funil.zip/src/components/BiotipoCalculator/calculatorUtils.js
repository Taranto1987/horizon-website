export const calculateIMC = (peso, altura) => {
  if (!peso || !altura || altura <= 0 || peso <= 0) return null;
  const alturaMetros = altura / 100;
  return peso / (alturaMetros * alturaMetros);
};

export const getDensidadeRecomendada = (imc) => {
  if (!imc) return 'Densidade não calculada';
  if (imc < 18.5) return 'D23 ou D26'; // Abaixo do peso
  if (imc < 24.9) return 'D28 ou D33'; // Peso normal
  if (imc < 29.9) return 'D33 ou D40'; // Sobrepeso
  return 'D45 ou Superior'; // Obesidade
};