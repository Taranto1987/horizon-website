import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { containsProfanity, filterProfanity } from './SalesBot/profanityFilter';

const SalesBot = ({ onClose }) => {
  const [messages, setMessages] = useState([]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    setTimeout(() => {
      addBotMessage("👋 Olá! Sou o assistente virtual da Loja Castor Cabo Frio! Como posso te ajudar a encontrar o sono perfeito hoje?", [
        { text: "🛏️ Ver Colchões", action: "show_colchoes" },
        { text: "📦 Ver Camas Box", action: "show_camas_box" },
        { text: "✨ Ver Conjuntos Box", action: "show_conjuntos" },
        { text: "🛋️ Ver Acessórios (Capas, Travesseiros)", action: "show_acessorios"},
        { text: "🧮 Calcular biotipo ideal", action: "calculator" },
        { text: "💰 Ofertas especiais", action: "offers" },
        { text: "📞 Falar com vendedor", action: "contact" }
      ]);
    }, 1000);
  }, []);

  const addBotMessage = (text, quickReplies = []) => {
    setIsTyping(true);
    setTimeout(() => {
      setMessages(prev => [...prev, {
        id: Date.now(),
        text,
        sender: 'bot',
        quickReplies,
        timestamp: new Date()
      }]);
      setIsTyping(false);
    }, 1500);
  };

  const addUserMessage = (text) => {
    setMessages(prev => [...prev, {
      id: Date.now(),
      text,
      sender: 'user',
      timestamp: new Date()
    }]);
  };

  const handleQuickReply = (action, text) => {
    addUserMessage(text);
    handleBotResponse(action);
  };

  const showProductCategory = (categoryName, products) => {
    let messageText = `🌟 Aqui estão alguns dos nossos ${categoryName} Castor:\n\n`;
    products.forEach(p => {
      messageText += `🔸 ${p.name} - R$ ${p.price.toLocaleString('pt-BR', {minimumFractionDigits: 2})}\n`;
    });
    messageText += "\nQual deles te interessa mais ou quer ver outra categoria?";
    
    const quickReplies = products.map(p => ({ text: `Detalhes: ${p.name}`, action: `details_${p.id}`}));
    quickReplies.push({ text: "⬅️ Voltar ao menu", action: "main_menu" });

    addBotMessage(messageText, quickReplies);
  }

  const handleBotResponse = (action) => {
    if (action.includes('ortobom')) {
        addBotMessage("Trabalhamos exclusivamente com produtos Castor! 😊 Posso te mostrar nossos modelos Castor?", [
            { text: "Sim, mostre os Castor!", action: "products" }
        ]);
        return;
    }

    switch (action) {
      case 'main_menu':
        addBotMessage("Como posso te ajudar agora?", [
            { text: "🛏️ Ver Colchões", action: "show_colchoes" },
            { text: "📦 Ver Camas Box", action: "show_camas_box" },
            { text: "✨ Ver Conjuntos Box", action: "show_conjuntos" },
            { text: "🛋️ Ver Acessórios", action: "show_acessorios"},
            { text: "🧮 Calcular biotipo", action: "calculator" },
        ]);
        break;
      case 'show_colchoes':
        showProductCategory("Colchões", [
            {id: 1, name: 'Colchão Castor Bonnel Class', price: 999.90},
            {id: 5, name: 'Colchão Castor Vitagel Pocket', price: 1899.90},
            {id: 8, name: 'Colchão Castor Gold Star Vitagel', price: 2199.90},
        ]);
        break;
      case 'show_camas_box':
         showProductCategory("Camas Box", [
            {id: 3, name: 'Cama Box Baú Castor Híbrido', price: 1499.90},
        ]);
        break;
      case 'show_conjuntos':
         showProductCategory("Conjuntos Box", [
            {id: 2, name: 'Conjunto Box Castor Sleep Max Pocket', price: 2399.90},
            {id: 7, name: 'Conjunto Box Castor Black & White Látex', price: 3499.90},
        ]);
        break;
      case 'show_acessorios':
        showProductCategory("Acessórios", [
            {id: 4, name: 'Travesseiro Castor Viscoelástico NASA', price: 159.90},
            {id: 6, name: 'Capa Protetora Impermeável Castor', price: 89.90},
        ]);
        break;
      case 'calculator':
        addBotMessage("🧮 Ótimo! Nossa calculadora de biotipo vai te ajudar a encontrar o colchão Castor perfeito. Quer abrir agora?", [
          { text: "✅ Sim, abrir calculadora", action: "open_calculator" },
          { text: "❓ Como funciona?", action: "explain_calculator" }
        ]);
        break;
      case 'offers':
        addBotMessage("🎉 OFERTAS ESPECIAIS CASTOR!\n\n💥 Colchão Bonnel Class: R$ 999,90 (era R$ 1.299,90)\n💥 Conjunto Sleep Max: R$ 2.399,90 (era R$ 2.999,90)\n\n🚀 Parcelamos em até 12x sem juros!", [
          { text: "🛒 Quero comprar", action: "buy_now" },
          { text: "📋 Ver mais produtos", action: "products" }
        ]);
        break;
      case 'contact':
        addBotMessage("📞 Claro! Nossos especialistas Castor estão prontos para atender você:\n\n🏪 Loja: (22) 9999-9999\n📱 WhatsApp: (22) 9999-9999\n📍 Rua Principal, 123 - Centro, Cabo Frio\n\n⏰ Horário: Seg-Sex 9h-18h | Sáb 9h-14h", [
          { text: "📞 Ligar agora", action: "call_now" },
          { text: "💬 WhatsApp", action: "whatsapp" },
          { text: "🗺️ Ver localização", action: "location" }
        ]);
        break;
      case 'open_calculator':
        toast({
          title: "🧮 Abrindo Calculadora",
          description: "Você será redirecionado para nossa calculadora de biotipo Castor.",
          duration: 3000,
        });
        setTimeout(() => {
          onClose();
        }, 2000);
        break;
      case 'buy_now':
         addBotMessage("🚀 EXCELENTE ESCOLHA! Para finalizar sua compra de produtos Castor:\n\n1️⃣ Qual produto Castor você deseja?\n2️⃣ Confirme o tamanho (Solteiro, Casal, Queen, King)\n3️⃣ Escolha a forma de pagamento\n\n💳 Aceitamos: PIX, cartão, boleto\n🚚 Entrega GRÁTIS em Cabo Frio\n🛡️ Garantia oficial Castor\n\n🎁 BÔNUS: Travesseiro Castor grátis na compra de conjuntos hoje!", [
            { text: "🛍️ Escolher produto", action: "products" },
            { text: "📞 Falar com vendedor", action: "contact" },
          ]);
        break;
      default:
        if (action.startsWith('details_')) {
            const productId = parseInt(action.split('_')[1]);
            const productMap = {
                1: {name: 'Colchão Castor Bonnel Class', price: 999.90, features: ['Molas Bonnel', 'Nível Firme', 'Antiácaro'], sizes: ['Solteiro', 'Casal']},
                2: {name: 'Conjunto Box Castor Sleep Max Pocket', price: 2399.90, features: ['Molas Pocket', 'Pillow Top Duplo', 'Malha'], sizes: ['Casal', 'Queen', 'King']},
                3: {name: 'Cama Box Baú Castor Híbrido', price: 1499.90, features: ['Amplo Espaço', 'Pistões a Gás', 'Reforçada'], sizes: ['Solteiro', 'Casal', 'Queen']},
                4: {name: 'Travesseiro Castor Viscoelástico NASA', price: 159.90, features: ['Viscoelástico', 'Automoldável', 'Capa Removível'], sizes: ['Padrão']},
                5: {name: 'Colchão Castor Vitagel Pocket', price: 1899.90, features: ['Gel Infused', 'Molas Pocket', 'Conforto Térmico'], sizes: ['Casal', 'Queen', 'King']},
                6: {name: 'Capa Protetora Impermeável Castor', price: 89.90, features: ['Impermeável', 'Respirável', 'Antiácaro'], sizes: ['Solteiro', 'Casal', 'Queen', 'King']},
                7: {name: 'Conjunto Box Castor Black & White Látex', price: 3499.90, features: ['Látex Natural', 'Molas Pocket', 'Design Moderno'], sizes: ['Queen', 'King']},
                8: {name: 'Colchão Castor Gold Star Vitagel', price: 2199.90, features: ['Vitagel', 'Molas Pocket', 'Pillow Top Alto'], sizes: ['Casal']},
            };
            const product = productMap[productId];
            if (product) {
                addBotMessage(`✨ Detalhes do ${product.name}:\n\nPreço: R$ ${product.price.toLocaleString('pt-BR', {minimumFractionDigits: 2})}\nCaracterísticas: ${product.features.join(', ')}\nTamanhos disponíveis: ${product.sizes.join(', ')}\n\nO que deseja fazer?`, [
                    { text: `🛒 Adicionar ${product.name} ao carrinho`, action: `add_cart_${productId}`},
                    { text: "📏 Ver outros tamanhos", action: `sizes_${productId}`},
                    { text: "⬅️ Voltar ao menu", action: "main_menu" },
                ]);
            } else {
                 addBotMessage("Desculpe, não encontrei detalhes para este produto. 😕", [{ text: "⬅️ Voltar ao menu", action: "main_menu" }]);
            }

        } else if (action.startsWith('add_cart_')) {
            const productId = parseInt(action.split('_')[1]);
             toast({ title: "🛒 Adicionado!", description: `Produto ${productId} adicionado ao carrinho.`, duration: 2000 });
             addBotMessage("Produto adicionado ao carrinho! 🎉 Deseja finalizar a compra ou ver mais produtos Castor?", [
                { text: "🛍️ Finalizar Compra", action: "checkout_not_implemented" },
                { text: "🎁 Ver mais produtos", action: "products" }
            ]);

        } else {
             addBotMessage("Desculpe, não entendi. 😕 Posso te ajudar com os produtos Castor, calculadora de biotipo ou ofertas?", [
                { text: "🛏️ Ver produtos Castor", action: "products" },
                { text: "🧮 Calcular biotipo", action: "calculator" }
            ]);
        }
    }
  };

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    const userMessage = inputValue.trim();

    if (containsProfanity(userMessage)) {
      addUserMessage(userMessage);
      addBotMessage("Por favor, evite usar linguagem ofensiva. Estou aqui para te ajudar a encontrar o colchão perfeito!", [
        { text: "🛏️ Ver produtos Castor", action: "products" },
        { text: "🧮 Calcular biotipo", action: "calculator" }
      ]);
      setInputValue("");
      return;
    }

    addUserMessage(userMessage);

    // Lógica de reconhecimento de intenção e funil de vendas
    let botResponseText = "Desculpe, não entendi. 😕 Posso te ajudar com os produtos Castor, calculadora de biotipo ou ofertas?";
    let quickReplies = [
      { text: "🛏️ Ver produtos Castor", action: "products" },
      { text: "🧮 Calcular biotipo", action: "calculator" },
      { text: "💰 Ver ofertas Castor", action: "offers" }
    ];

    const lowerCaseMessage = userMessage.toLowerCase();

    if (lowerCaseMessage.includes("olá") || lowerCaseMessage.includes("oi") || lowerCaseMessage.includes("bom dia") || lowerCaseMessage.includes("boa tarde") || lowerCaseMessage.includes("boa noite")) {
      botResponseText = "👋 Olá! Como posso te ajudar a encontrar o sono perfeito hoje?";
      quickReplies = [
        { text: "🛏️ Ver Colchões", action: "show_colchoes" },
        { text: "📦 Ver Camas Box", action: "show_camas_box" },
        { text: "✨ Ver Conjuntos Box", action: "show_conjuntos" },
        { text: "🛋️ Ver Acessórios", action: "show_acessorios"},
        { text: "🧮 Calcular biotipo ideal", action: "calculator" },
        { text: "💰 Ofertas especiais", action: "offers" },
        { text: "📞 Falar com vendedor", action: "contact" }
      ];
    } else if (lowerCaseMessage.includes("colchão") || lowerCaseMessage.includes("colchoes") || lowerCaseMessage.includes("cama") || lowerCaseMessage.includes("camas") || lowerCaseMessage.includes("produto") || lowerCaseMessage.includes("produtos")) {
      botResponseText = "Ótimo! Para te ajudar a encontrar o colchão ideal, você busca por:";
      quickReplies = [
        { text: "🛏️ Colchões", action: "show_colchoes" },
        { text: "📦 Camas Box", action: "show_camas_box" },
        { text: "✨ Conjuntos Box", action: "show_conjuntos" },
        { text: "🛋️ Acessórios", action: "show_acessorios"},
        { text: "⬅️ Voltar ao menu", action: "main_menu" }
      ];
    } else if (lowerCaseMessage.includes("oferta") || lowerCaseMessage.includes("promoção") || lowerCaseMessage.includes("desconto")) {
      botResponseText = "🎉 Temos ofertas incríveis esperando por você!";
      quickReplies = [
        { text: "💰 Ver ofertas especiais", action: "offers" },
        { text: "🛒 Quero comprar", action: "buy_now" },
        { text: "⬅️ Voltar ao menu", action: "main_menu" }
      ];
    } else if (lowerCaseMessage.includes("contato") || lowerCaseMessage.includes("vendedor") || lowerCaseMessage.includes("falar")) {
      botResponseText = "📞 Nossos especialistas estão prontos para te atender!";
      quickReplies = [
        { text: "📞 Ligar agora", action: "call_now" },
        { text: "💬 WhatsApp", action: "whatsapp" },
        { text: "⬅️ Voltar ao menu", action: "main_menu" }
      ];
    } else if (lowerCaseMessage.includes("biotipo") || lowerCaseMessage.includes("calculadora")) {
      botResponseText = "🧮 Nossa calculadora de biotipo vai te ajudar a encontrar o colchão Castor perfeito!";
      quickReplies = [
        { text: "✅ Sim, abrir calculadora", action: "open_calculator" },
        { text: "❓ Como funciona?", action: "explain_calculator" },
        { text: "⬅️ Voltar ao menu", action: "main_menu" }
      ];
    } else if (lowerCaseMessage.includes("comprar") || lowerCaseMessage.includes("finalizar") || lowerCaseMessage.includes("carrinho")) {
      botResponseText = "🚀 Excelente! Para finalizar sua compra:";
      quickReplies = [
        { text: "🛍️ Escolher produto", action: "products" },
        { text: "📞 Falar com vendedor", action: "contact" },
        { text: "⬅️ Voltar ao menu", action: "main_menu" }
      ];
    }

    setTimeout(() => {
      addBotMessage(botResponseText, quickReplies);
    }, 1000);
    setInputValue("");
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.8, opacity: 0 }}
        className="bg-card rounded-2xl w-full max-w-md h-[70vh] max-h-[650px] flex flex-col overflow-hidden glass-effect-castor"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="bg-gradient-to-r from-primary to-primary-accent p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary-foreground/20 rounded-full flex items-center justify-center">
              <Bot className="w-6 h-6 text-primary-foreground" />
            </div>
            <div>
              <h3 className="font-semibold text-primary-foreground">Assistente Castor</h3>
              <p className="text-xs text-primary-foreground/80">Especialista em colchões Castor</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="text-primary-foreground hover:bg-primary-foreground/20"
          >
            <X className="w-5 h-5" />
          </Button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4 scroll-smooth">
          <AnimatePresence>
            {messages.map((message) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-[85%] ${
                  message.sender === 'user'
                    ? 'bg-primary text-primary-foreground rounded-2xl rounded-br-lg'
                    : 'bg-secondary text-secondary-foreground rounded-2xl rounded-bl-lg chat-bubble'
                } p-3 shadow-md`}>
                  <p className="text-sm whitespace-pre-line">{message.text}</p>
                  
                  {message.quickReplies && message.quickReplies.length > 0 && (
                    <div className="mt-3 grid grid-cols-1 gap-2">
                      {message.quickReplies.map((reply, index) => (
                        <button
                          key={index}
                          onClick={() => handleQuickReply(reply.action, reply.text)}
                          className="block w-full text-left bg-primary/10 hover:bg-primary/20 border border-primary/30 rounded-lg px-3 py-2 text-sm text-primary transition-colors duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-primary-accent"
                        >
                          {reply.text}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {isTyping && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex justify-start"
            >
              <div className="bg-secondary rounded-2xl rounded-bl-lg p-3 chat-bubble shadow-md">
                <div className="flex items-center gap-1.5">
                  <div className="typing-indicator"></div>
                  <div className="typing-indicator"></div>
                  <div className="typing-indicator"></div>
                </div>
              </div>
            </motion.div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <div className="p-4 border-t border-border bg-card/50">
          <div className="flex gap-2">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="Digite sua mensagem..."
              className="flex-1 bg-secondary border border-border rounded-lg px-4 py-2.5 text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-shadow duration-150"
            />
            <Button
              onClick={handleSendMessage}
              size="icon"
              className="button-castor-primary rounded-lg w-11 h-11 transition-transform duration-150 ease-in-out active:scale-95"
              aria-label="Enviar mensagem"
            >
              <Send className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default SalesBot;